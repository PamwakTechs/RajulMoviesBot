# ==========================
# TELEGRAM
# ==========================

BOT_TOKEN = "8975236029:AAGApycMV0dngnRNOtwzxnHXjkx91KxiLy8"

BOT_USERNAME = "Hub001bot"

ADMIN_ID = 8033843877

ADMIN_USERNAME = "@Pseudolegend"

ADMIN_PHONE = "0101067205"


# ==========================
# CHANNELS
# ==========================

PRIVATE_CHANNEL_ID = -1003978585564

PUBLIC_CHANNEL_ID = -1004367259022


# ==========================
# PAYHERO
# ==========================

PAYHERO_BASE_URL = "https://backend.payhero.co.ke/api/v2/payments"

PAYHERO_USERNAME = "aXNnVzMF25ph68rv9Atw"

PAYHERO_PASSWORD = "K1Ov5LQcage8WVgOAuUw8agMNLDlW61dwg9Ogpnf"

PAYHERO_ACCOUNT_ID = "11004"

PAYHERO_CHANNEL_ID = "10722"

CALLBACK_URL = "https://YOUR_CALLBACK_URL/payhero/callback"


# ==========================
# PRICES
# ==========================

DEFAULT_PART_PRICE = 10

KENYAN_LEAKS_PRICE = 20


# ==========================
# DATABASE
# ==========================

DB_NAME = "movies.db"

