from flask import Flask, request, jsonify

from database import execute

app = Flask(__name__)


@app.route("/payhero/callback", methods=["POST"])
def payhero_callback():

    data = request.get_json(force=True)

    reference = (
        data.get("external_reference")
        or data.get("reference")
        or ""
    )

    status = (
        data.get("status")
        or ""
    ).upper()

    if status == "SUCCESS":

        execute(
            """
            UPDATE orders
            SET status='PAID'
            WHERE checkout_id=?
            """,
            (reference,)
        )

    return jsonify(
        {
            "success": True
        }
    )


if __name__ == "__main__":
    app.run(
        host="0.0.0.0",
        port=8000
    )
